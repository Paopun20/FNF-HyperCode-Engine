Put your images here!

You can put your custom logo or an image that you can use as a background here and edit the specific variables within gfDanceTitle.json.

For more info, each subdirectory has a readme.txt file.