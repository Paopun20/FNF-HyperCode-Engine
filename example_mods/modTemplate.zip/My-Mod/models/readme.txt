Add your custom models here.
The model file can be a .obj, .awd, .3ds, .ac3d, .md2, .md5, or a .dae file, though .awd files are prefered.